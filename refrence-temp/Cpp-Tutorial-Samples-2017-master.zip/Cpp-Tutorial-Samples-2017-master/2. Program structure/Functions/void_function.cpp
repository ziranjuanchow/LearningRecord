// void function example
#include <iostream>

using namespace std;

void printmessage()
{
    cout << "I'm a function!";
}

int main()
{
    printmessage();
}