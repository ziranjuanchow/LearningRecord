// static vs automatic storage
#include <iostream>

using namespace std;

int x;

int main()
{
    int y;

    cout << x << '\n';
    cout << y << '\n';

    return 0;
}