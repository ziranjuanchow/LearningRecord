#include <iostream>

using namespace std;

#define PI 3.14159
#define NEWLINE '\n'

int main()
{
    double r = 5.0;               // radius
    double circle;

    circle = 2 * PI * r;
    cout << circle;
    cout << NEWLINE;

}