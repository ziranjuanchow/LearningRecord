// i/o example

#include <iostream>

using namespace std;

int main()
{
    int age = 21;
    int zipcode = 22313;

    cout << "I am " << age << " years old and my zipcode is " << zipcode;

    return 0;
}