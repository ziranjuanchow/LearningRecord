// conditional operator
#include <iostream>

using namespace std;

int main()
{
    int a, b, c;

    a = 2;
    b = 7;
    c = (a > b) ? a : b;

    cout << c << '\n';
}