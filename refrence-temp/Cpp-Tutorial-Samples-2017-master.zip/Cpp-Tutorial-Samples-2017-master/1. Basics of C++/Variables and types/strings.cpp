// my first string
#include <iostream>
#include <string>

using namespace std;

int main()
{
    string mystring;

    mystring = "This is a string";
    cout << mystring;

    return 0;
}