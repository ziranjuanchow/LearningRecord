// my second program in C++
#include <iostream>

int main()
{
    std::cout << "Hello World! ";
    std::cout << "I'm a C++ program";
}