// my second program in C++
#include <iostream>

using namespace std;

int main()
{
    cout << "Hello World! ";
    cout << "I'm a C++ program";
}