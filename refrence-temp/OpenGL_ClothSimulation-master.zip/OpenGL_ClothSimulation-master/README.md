OpenGL Cloth simulation
====================================

## Description

Based on "Mosegaards Cloth Simulation Coding Tutorial" ( http://cg.alexandra.dk/2009/06/02/mosegaards-cloth-simulation-coding-tutorial/ )

The real purpose of this code is to discover and describe how the same code can be implemented using different versions of OpenGL.

## Installation

I assume that you have FreeGlut, GLEW and GLM installed in the most recent version.

http://freeglut.sourceforge.net/ (MSVC version: http://www.transmissionzero.co.uk/software/freeglut-devel/ )

http://glew.sourceforge.net/

http://glm.g-truc.net/

Also the code requires that your graphics cards drivers supports OpenGL 4.3.

