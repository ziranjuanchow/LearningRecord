#ifndef TEXT_RESOURCE
#define TEXT_RESOURCE

class TextResource
{
public:
	static char* load(const char *name);
};

#endif
