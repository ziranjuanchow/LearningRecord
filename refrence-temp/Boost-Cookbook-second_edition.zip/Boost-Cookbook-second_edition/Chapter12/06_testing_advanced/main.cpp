#define BOOST_TEST_MODULE test_module_name
#include <boost/test/unit_test.hpp>
