This directory contains preprocessed code from the ../Chapter06 folder:
* All the headers were copyied into the main.cpp
* Include guards were removed
* Project files updated accordingly

Files in this folder are used by online compiler (it can not deal with foreign includes).
