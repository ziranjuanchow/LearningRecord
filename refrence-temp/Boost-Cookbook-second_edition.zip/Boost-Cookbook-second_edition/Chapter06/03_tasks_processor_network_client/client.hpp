// Helper heade file
extern bool g_authed;
const unsigned short g_port_num = 65001;

void send_auth();
