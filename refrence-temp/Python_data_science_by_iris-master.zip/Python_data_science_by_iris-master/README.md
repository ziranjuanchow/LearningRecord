# Python_data_science_by_iris

本项目为机器学习的学习笔记
用iris.csv作为数据集
测试了一下功能代码

1.条状图显示组平均数，可以从图上看出不同的花种类中，他们的属性特点

2.画kde图

3.四种属性特征的平均值 条状图

4.用numpy创建随机值，测试，与数据项目无关

5.绘制样本图

6.用sqlite3读取数据

7.用pandas读取数据

8.用原生Python读取数据

9.用sqlalchemy 读取数据

10.用sklearn的交叉验证 训练数据集

11.用sklearn的KNN 训练数据集

12.用sklearn的逻辑斯蒂回归 训练数据集

13.用sklearn的朴素贝叶斯 训练数据集

14.用sklearn的交叉验证 KNN 逻辑蒂斯回归 三种方式 训练数据集 并对比

13.用sklearn的SVM 训练数据集
