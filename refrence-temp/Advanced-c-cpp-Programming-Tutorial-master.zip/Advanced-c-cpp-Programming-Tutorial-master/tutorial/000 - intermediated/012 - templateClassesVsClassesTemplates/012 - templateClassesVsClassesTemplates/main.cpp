//
//  main.cpp
//  012 - templateClassesVsClassesTemplates
//
//  Created by Victor Bolinches Marin on 29/11/15.
//  Copyright © 2015 Victor Bolinches Marin. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Class template is a template used to generate template classes.\n";
    std::cout << "Template class is an instance of a class template.\n";
    return 0;
}
