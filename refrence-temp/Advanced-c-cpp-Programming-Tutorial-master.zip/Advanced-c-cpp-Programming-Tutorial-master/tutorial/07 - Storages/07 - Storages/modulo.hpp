//
//  modulo.hpp
//  000 - Storages
//
//  Created by Victor Bolinches Marin on 19/11/15.
//  Copyright © 2015 Victor Bolinches Marin. All rights reserved.
//

#ifndef modulo_hpp
#define modulo_hpp

#include <stdio.h>
int funcion();
#endif /* modulo_hpp */